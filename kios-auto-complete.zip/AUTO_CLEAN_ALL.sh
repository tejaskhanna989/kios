#!/bin/bash

# Complete automated cleanup
set -e

echo "=== Complete Cleanup ==="

# Uninstall apps
adb shell am force-stop com.kios.ios
adb shell pm uninstall com.kios.ios
adb shell am force-stop com.termux
adb shell pm uninstall com.termux

# Remove files
adb shell rm -rf /data/data/com.termux/files/home/qemu-sptm
adb shell rm -rf /data/local/tmp/kios-fix
adb shell rm -rf /sdcard/Download/kios

echo "✅ Cleanup complete!"
