#!/bin/bash

# Complete automated iOS 12 installation
set -e

echo "=== Automated iOS 12 Installation ==="

# Check if device is connected
if ! adb devices | grep -q "device"; then
    echo "❌ Connect your device via USB!"
    exit 1
fi

# Download and install Termux
echo "Installing Termux..."
adb shell am start -n com.android.packageinstaller/.PackageInstallerActivity -d 'market://details?id=com.termux' || true
echo "Please install Termux from Play Store, then press Enter..."
read -p ""

# Install required packages
adb shell input text "pkg update && pkg install clang git make python libslirp pixman"
adb shell input tap 500 1400
sleep 10

# Build QEMU
adb shell input text "git clone https://github.com/tejaskhanna989/qemu-sptm.git"
adb shell input tap 500 1400
sleep 5
adb shell input text "cd qemu-sptm && git checkout asoft-android"
adb shell input tap 500 1400
sleep 3
adb shell input text "./configure --target-list=aarch64-softmmu --disable-system --enable-user --disable-capstone --disable-slirp"
adb shell input tap 500 1400
sleep 3
adb shell input text "make -j\$(nproc)"
adb shell input tap 500 1400
sleep 30

# Copy libraries and install
adb shell input text "./pull-libs.sh /data/data/com.termux/files/home/qemu-sptm/qemu-system-aarch64"
adb shell input tap 500 1400
sleep 10

echo "✅ Installation complete! iOS 12 is ready!"
